import navbar from "../components/Navbar.js";

document.getElementById("navbar").innerHTML = navbar()
